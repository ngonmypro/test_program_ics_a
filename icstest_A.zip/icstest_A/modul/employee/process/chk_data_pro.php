<?php include "../../../connect/connect_mysql.php";

    if ($_POST['EmpStatus'] == 'add') {
      $sql_se = " SELECT EmployeeId FROM employee WHERE EmployeeId = '".$_POST['add_emp_code']."'";
      $result_se = mysql_query($sql_se)or die(mysql_error());
        if(mysql_num_rows($result_se) != 0){
      	   echo "N";
         }else{
           $sql_in = " INSERT INTO employee (EmployeeName, EmployeeAddress, EmployeeDepartment)
           VALUES ('".$_POST['add_emp_name']."','".$_POST['add_emp_address']."','".$_POST['add_emp_department']."')";
           $result_in = mysql_query($sql_in)or die(mysql_error());
            echo "Y";
         }

    }else if ($_POST['EmpStatus'] == 'edit') {
      $sql_up = "UPDATE employee SET EmployeeName = '".$_POST['edit_emp_name']."', EmployeeAddress = '".$_POST['edit_emp_address']."', EmployeeDepartment = '".$_POST['edit_emp_department']."' WHERE EmployeeId = '".$_POST['EmpId']."'";
      $result_up = mysql_query($sql_up)or die(mysql_error());
        echo "Y";

    }elseif ($_POST['EmpStatus'] == 'delete') {
      $sql_del = "DELETE FROM employee WHERE EmployeeId = '".$_POST['EmpId']."'";
      $result_del = mysql_query($sql_del)or die(mysql_error());
        echo "Y";

    }else {
      echo "N";
    }

  mysql_close($c);
 ?>
