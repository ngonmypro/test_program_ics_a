<?php include "../../../connect/connect_mysql.php";

  $sql_edit = "SELECT * FROM employee WHERE EmployeeId = '".$_POST['EmpId']."'";
  $result_edit = mysql_query($sql_edit)or die(mysql_error());
  while ($row_edit = mysql_fetch_array($result_edit)) {
 ?>
<div data-parsley-validate class="form-horizontal form-label-left">

  <!--<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">รหัสพนักงาน</label>
      <div class="col-md-7 col-sm-7 col-xs-12">
        <input type='text' class="form-control" id="edit_emp_code" placeholder="กรุณากรอก รหัสพนักงาน" value="<?php# echo $row_edit['EmployeeId']; ?>"/>
      </div>
    </div>-->

    <div class="form-group">
      <label class="control-label col-md-3 col-sm-3 col-xs-12">NAME</label>
        <div class="col-md-7 col-sm-7 col-xs-12">
          <input type='text' class="form-control" id="edit_emp_name" placeholder="Please enter the name" maxlength="200" value="<?php echo $row_edit['EmployeeName']; ?>"/>
        </div>
      </div>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Address</label>
          <div class="col-md-7 col-sm-7 col-xs-12">
            <textarea rows="3"  class="form-control" id="edit_emp_address" placeholder="Please enter the address" value=""><?php echo $row_edit['EmployeeAddress']; ?></textarea>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Department</label>
          <div class="col-md-7 col-sm-7 col-xs-12">
            <input type='text' class="form-control" id="edit_emp_department" placeholder="Please enter the department" maxlength="100" value="<?php echo $row_edit['EmployeeDepartment']; ?>"/>
          </div>
        </div>

</div>
<?php }

  mysql_close($c);

?>
